package exception;

public class MismatchedParametersException extends Exception{
	
}