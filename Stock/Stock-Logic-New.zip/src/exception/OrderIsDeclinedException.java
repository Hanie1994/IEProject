package exception;

public class OrderIsDeclinedException extends Exception{
	
}