package exception;

public class OrderIsQueuedException extends Exception{
	
}
