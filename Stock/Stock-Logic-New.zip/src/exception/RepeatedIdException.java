package exception;

public class RepeatedIdException extends Exception{
	
}