package exception;

public class UnknownUserIdException extends Exception{
	
}