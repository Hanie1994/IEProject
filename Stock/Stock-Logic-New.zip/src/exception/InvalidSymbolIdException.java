package exception;

public class InvalidSymbolIdException extends Exception{
	
}