package exception;

public class UnknownCommandException extends Exception{
	
}