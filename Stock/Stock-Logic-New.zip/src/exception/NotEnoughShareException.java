package exception;

public class NotEnoughShareException extends Exception{
	
}