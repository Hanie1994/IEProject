package exception;

public class InvalidOrderTypeException extends Exception{
	
}