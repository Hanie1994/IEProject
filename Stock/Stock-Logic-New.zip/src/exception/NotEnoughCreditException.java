package exception;

public class NotEnoughCreditException extends Exception{
	
}